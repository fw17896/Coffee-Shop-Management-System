import java.io.Serializable;

class Product implements Serializable {
    private String name;
    private String size;
    private int quantity;
    private double price;

    public Product(String name, String size, int quantity, double price) {
        this.name = name;
        this.size = size;
        this.quantity = quantity;
        this.price = price;
    }
    public String getName() {
        return name;
    }
    public String getSize() {
        return size;
    }
    public int getQuantity() {
        return quantity;
    }
    public void setQuantity(int quantity) {
        this.quantity = quantity;
    }
    public double getPrice() {
        return price;
    }

    public void setPrice(double price) {
        if (price < 0) {
            throw new IllegalArgumentException("Price cannot be negative.");
        }
        this.price = price;
    }
    public String toString() {
        return "Product: " + name + " | Size: " + size + " | Quantity: " + quantity + " | Price: $" + price;
    }
}
