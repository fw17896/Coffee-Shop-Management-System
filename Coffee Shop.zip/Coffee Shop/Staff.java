import java.util.*;
import java.io.*;

class Staff implements Serializable {
    private String id;
    private String password;

    public Staff(String id, String password) {
        this.id = id;
        this.password = password;
    }

    public String getId() {
        return id;
    }

    public String getPassword() {
        return password;
    }
}
class StaffMenu extends Menu {
    private Inventory inventory = new Inventory();
    private GenericListManager<Staff> staffManager = new GenericListManager<>(CoffeeShop.STAFF_FILE);

    @Override
    public void displayMenu() {
        Scanner scanner = new Scanner(System.in);

        while (true) {
            try {
                System.out.println("\n--- Staff Menu ---");
                System.out.println("1. Add Products");
                System.out.println("2. Check Inventory");
                System.out.println("3. Modify Inventory");
                System.out.println("4. Exit to Main Menu");
                System.out.print("Choose an option: ");

                int choice = scanner.nextInt();

                switch (choice) {
                    case 1:
                        inventory.addProduct();
                        break;
                    case 2:
                        inventory.checkInventory();
                        break;
                    case 3:
                        inventory.modifyInventory();
                        break;
                    case 4:
                        return;
                    default:
                        throw new IllegalArgumentException("Invalid choice! Please choose a valid option.");
                }
            } catch (InputMismatchException e) {
                System.out.println("Invalid input! Please enter a number.");
                scanner.nextLine(); // Clear invalid input
            } catch (IllegalArgumentException e) {
                System.out.println(e.getMessage());
            }
        }
    }
}



