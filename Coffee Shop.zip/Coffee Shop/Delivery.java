class Delivery {
    private String name;
    private String address;
    private String city;
    private String phone;

    public Delivery(String name, String address, String city, String phone) {
        this.name = name;
        this.address = address;
        this.city = city;
        this.phone = phone;
    }

    public String toString() {
        return "Name: "+ name +" | \tAddress: " + address + " | \tCity: " + city + " | \tPhone: " + phone;
    }
}