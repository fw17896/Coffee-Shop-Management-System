import java.io.Serializable;
import java.util.ArrayList;
import java.util.InputMismatchException;
import java.util.List;
import java.util.Scanner;

class Customer implements Serializable {
    private String name;
    private String address;
    private String city;
    private String phone;
    private String password;

    public Customer(String name, String address, String city, String phone, String password) {
        this.name = name;
        this.address = address;
        this.city = city;
        this.phone = phone;
        this.password = password;
    }

    public String getName() {
        return name;
    }

    public String getPassword() {
        return password;
    }
}

    class CustomerMenu extends Menu {
        private Inventory inventory = new Inventory();
        private List<Product> cart = new ArrayList<>();
        private GenericListManager<Customer> customerManager = new GenericListManager<>(CoffeeShop.CUSTOMERS_FILE);
        private Delivery delivery;

        public void displayMenu() {
            Scanner scanner = new Scanner(System.in);

            while (true) {
                System.out.println("\n--- Customer Menu ---");
                System.out.println("1. View Products");
                System.out.println("2. Add to Cart");
                System.out.println("3. View Cart");
                System.out.println("4. Add Delivery Details");
                System.out.println("5. View Delivery Details");
                System.out.println("6. Checkout");
                System.out.println("7. Exit to Main Menu");
                System.out.print("Choose an option: ");
                int choice = scanner.nextInt();

                switch (choice) {
                    case 1:
                        inventory.checkInventory();
                        break;
                    case 2:
                        addToCart();
                        break;
                    case 3:
                        viewCart();
                        break;
                    case 4:
                        addDeliveryDetails();
                        break;
                    case 5:
                        viewDeliveryDetails();
                        break;
                    case 6:
                        checkout();
                        break;
                    case 7:
                        return;
                    default:
                        System.out.println("Invalid choice! Please try again.");
                }
            }
        }
        public static boolean isValidSize(String size) {
            return size.equals("S") || size.equals("M") || size.equals("L") || size.equals("XL");
        }

        private void addToCart() {
            Scanner scanner = new Scanner(System.in);
            String name;
            while (true) {
                System.out.print("Enter product name to add to cart: ");
                name = scanner.nextLine();
                if (isValidName(name)) {
                    break;
                } else {
                    System.out.println("Invalid name. Name cannot be a number.");
                }
            }
            String size = null;
            while (true) {
                try {
                    System.out.print("Enter product size (S, M, L, XL): ");
                    size = scanner.nextLine().trim().toUpperCase();
                    if (size.isEmpty() || !isValidSize(size)) {
                        throw new IllegalArgumentException("Invalid size! Size must be S, M, L, or XL.");
                    }
                    break;
                } catch (IllegalArgumentException e) {
                    System.out.println(e.getMessage());
                }
            }
            int quantity;
            while (true) {
                try {
                    System.out.print("Enter product quantity: ");
                    quantity = scanner.nextInt();
                    if (quantity <= 0) {
                        throw new IllegalArgumentException("Quantity must be greater than zero.");
                    }
                    break;
                } catch (InputMismatchException e) {
                    System.out.println("Invalid input! Please enter a valid integer for quantity.");
                    scanner.nextLine();
                } catch (IllegalArgumentException e) {
                    System.out.println(e.getMessage());
                }
            }

            Product product = inventory.findProduct(name, size);
            if (product != null && product.getQuantity() >= quantity) {
                boolean productExists = false;
                for (Product cartProduct : cart) {
                    if (cartProduct.getName().equalsIgnoreCase(name) && cartProduct.getSize().equalsIgnoreCase(size)) {
                        cartProduct.setQuantity(cartProduct.getQuantity() + quantity);
                        productExists = true;
                        break;
                    }
                }
                if (!productExists) {
                    cart.add(new Product(name, size, quantity, product.getPrice()));
                }
                product.setQuantity(product.getQuantity() - quantity);
                inventory.saveInventory();
                System.out.println("Product added to cart!");
            } else {
                System.out.println("Product not available or insufficient quantity.");
            }
        }

        private void viewCart() {
            System.out.println("\n--- Cart Details ---");
            if (cart.isEmpty()) {
                System.out.println("\nNo products found in cart.");
            }
            else {
                double total = 0;
                for (Product product : cart) {
                    System.out.println(product);
                    total += product.getPrice() * product.getQuantity();
                }
                System.out.println("\nTotal Amount: " + total);
            }
        }

        private void addDeliveryDetails() {
            Scanner scanner = new Scanner(System.in);

            String RecpientName;
            while (true) {
                System.out.print("Enter recipient name: ");
                RecpientName = scanner.nextLine();
                if (isValidName(RecpientName)) {
                    break;
                } else {
                    System.out.println("Invalid name. Name cannot be a number.");
                }
            }
            System.out.print("Enter delivery address: ");
            String address = scanner.nextLine();
            System.out.print("Enter city: ");
            String city = scanner.nextLine();

            String phone ;
            while (true) {
                System.out.print("Enter Phone Number: ");
                phone = scanner.nextLine();
                if (isValidPhoneNumber(phone)) {
                    break;
                } else {
                    System.out.println("Invalid phone number. It must be 11 digits.");
                }
            }

            delivery = new Delivery(RecpientName, address, city, phone);
            System.out.println("Delivery details added successfully!");
        }

        private void viewDeliveryDetails() {
            if (delivery == null) {
                System.out.println("\nNo delivery details available.");
            } else {
                System.out.println("\n--- Delivery Details ---");
                System.out.println(delivery);
            }
        }


        public void checkout() {
            if (cart.isEmpty()) {
                System.out.println("\nNo products found in cart.");
            } else {
                Scanner scanner = new Scanner(System.in);
                System.out.print("\nAre you sure you want to proceed with the checkout? (Y/N): ");
                String confirmation = scanner.nextLine().trim().toUpperCase();

                if (confirmation.equals("Y")) {
                    if(!cart.isEmpty()) {
                        if (delivery == null) {
                            System.out.println("\nDelivery details not provided. Provide details first.");
                            addDeliveryDetails();
                        }
                        viewDeliveryDetails();
                        System.out.println("\nThank you for your purchase! Your order will be processed.");
                        cart.clear();
                    }
                    System.out.println("Cart is empty.");
                }
                System.out.print("\nDo you want to continue shopping(Y/N)?");
                String continueShopping = scanner.nextLine().trim().toUpperCase();
                if (continueShopping.equals("N")) {
                    for (Product cartProduct : cart) {
                        Product productInInventory = inventory.findProduct(cartProduct.getName(), cartProduct.getSize());
                        if (productInInventory != null) {
                            productInInventory.setQuantity(productInInventory.getQuantity() + cartProduct.getQuantity());
                        } else {
                            inventory.addProductFromCart(cartProduct);
                        }
                    }
                }
            }
        }

        private boolean isValidPhoneNumber(String phone) {
            return phone.matches("\\d{11}");
        }
    }


