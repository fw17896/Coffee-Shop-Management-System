import java.util.*;
import java.io.*;

abstract class Menu {
    public abstract void displayMenu();
    public static boolean isValidName(String name) {
        return !name.matches(".\\d.");
    }

}

class GenericListManager<T> {
    private String fileName;

    public GenericListManager(String fileName) {
        this.fileName = fileName;
    }

    public void saveToFile(List<T> list) {
        try (ObjectOutputStream oos = new ObjectOutputStream(new FileOutputStream(fileName))) {
            oos.writeObject(list);
            System.out.println("List saved to file: " + fileName);
        } catch (IOException e) {
            System.out.println("Error saving to file: " + e.getMessage());
        }
    }

    public List<T> loadFromFile() {
        try (ObjectInputStream ois = new ObjectInputStream(new FileInputStream(fileName))) {
            return (List<T>) ois.readObject();
        } catch (IOException | ClassNotFoundException e) {
            System.out.println("Error loading from file: " + e.getMessage());
            return new ArrayList<>();
        }
    }

    public void addItem(List<T> list, T item) {
        list.add(item);
    }

    public void displayList(List<T> list) {
        for (T item : list) {
            System.out.println(item);
        }
    }
}

public class CoffeeShop{
    public static final String INVENTORY_FILE = "Inventory.bin";
    public static final String PRODUCTS_FILE = "Products.bin";
    public static final String ORDERS_FILE = "Orders.bin";
    public static final String CUSTOMERS_FILE = "Customers.bin";
    public static final String STAFF_FILE = "Staff.bin";

    public static void main(String[] args) {
        createFilesIfNotExist();

        GenericListManager<Customer> customerManager = new GenericListManager<>(CUSTOMERS_FILE);
        GenericListManager<Staff> staffManager = new GenericListManager<>(STAFF_FILE);
        GenericListManager<Inventory> inventoryManager = new GenericListManager<>(INVENTORY_FILE);
        GenericListManager<Product> productManager = new GenericListManager<>(PRODUCTS_FILE);

        Scanner scanner = new Scanner(System.in);
        StaffMenu staffMenu = new StaffMenu();
        CustomerMenu customerMenu = new CustomerMenu();
        ArrayList<Staff> staffList = createDefaultStaff();
        ArrayList<Customer> customerList = loadCustomersFromFile(CUSTOMERS_FILE);

        while (true) {
            System.out.println("\n--- Coffee Shop App ---");
            System.out.println("1. Login as Staff");
            System.out.println("2. Login as Customer");
            System.out.println("3. Sign Up as New Customer");
            System.out.println("4. Exit");
            System.out.print("Choose an option: ");
            int choice = getValidIntInput();

            switch (choice) {
                case 1:
                    if (staffLogin(staffList)) {
                        new StaffMenu().displayMenu();
                    }
                    break;
                case 2:
                    if (customerLogin(customerList)) {
                        customerMenu.displayMenu();
                    }
                    break;
                case 3:
                    signUpCustomer(customerList);
                    break;
                case 4:
                    saveCustomersToFile(CUSTOMERS_FILE, customerList);
                    System.out.println("Exiting the system. Goodbye!");
                    return;
                default:
                    System.out.println("Invalid choice! Please try again.");
            }
        }
    }

    private static void saveCustomersToFile(String fileName, ArrayList<Customer> customerList) {
        try (ObjectOutputStream oos = new ObjectOutputStream(new FileOutputStream(fileName))) {
            oos.writeObject(customerList);
        } catch (IOException e) {
            System.out.println("Error saving customers: " + e.getMessage());
        }
    }

    public static void createFilesIfNotExist() {
        createFileIfNotExist(INVENTORY_FILE);
        createFileIfNotExist(PRODUCTS_FILE);
        createFileIfNotExist(ORDERS_FILE);
        createFileIfNotExist(CUSTOMERS_FILE);
        createFileIfNotExist(STAFF_FILE);
    }

    public static void createFileIfNotExist(String fileName) {
        File file = new File(fileName);
        if (!file.exists()) {
            try (ObjectOutputStream oos = new ObjectOutputStream(new FileOutputStream(file))) {
                oos.writeObject(new ArrayList<>());
                System.out.println("File created: " + fileName);
            } catch (IOException e) {
                System.out.println("Error creating file: " + e.getMessage());
            }
        } else {
            System.out.println("File already exists: " + fileName);
        }
    }

    private static ArrayList<Staff> createDefaultStaff() {
        ArrayList<Staff> staffList = new ArrayList<>();
        staffList.add(new Staff("Staff1", "password1"));
        staffList.add(new Staff("Staff2", "password2"));
        return staffList;
    }

    private static boolean staffLogin(ArrayList<Staff> list) {
        Scanner scanner = new Scanner(System.in);
        String staffId;
        String password;
        Staff currentStaff = null;

        while (true) {
            System.out.print("Enter Staff ID: ");
            staffId = scanner.nextLine();

            if (isValidStaffId(staffId)) {
                for (Staff staff : list) {
                    if (staff.getId().equalsIgnoreCase(staffId)) {
                        currentStaff = staff;
                        break;
                    }
                }

                if (currentStaff != null) {
                    break;
                } else {
                    System.out.println("Staff ID not found. Please try again.");
                }
            } else {
                System.out.println("Invalid Staff ID format. Please try again.");
            }
        }

        while (true) {
            System.out.print("Enter Password: ");
            password = scanner.nextLine();

            if (currentStaff.getPassword().equals(password)) {
                System.out.println("Login successful!");
                return true;
            } else {
                System.out.println("Incorrect Password. Please try again.");
            }
        }
    }

    private static boolean customerLogin(ArrayList<Customer> list) {
        Scanner scanner = new Scanner(System.in);
        System.out.println("\n--- Customer Login ---");
        String name;
        while (true) {
            System.out.print("Enter Customer Name: ");
            name = scanner.nextLine();
            if (isValidName(name)) {
                break;
            } else {
                System.out.println("Invalid name. Name cannot be a number.");
            }
        }

        String password;
        while (true) {
            System.out.print("Enter Password: ");
            password = scanner.nextLine();
            if (isValidPassword(password)) {
                System.out.println("Password is valid.");
                break;
            } else {
                System.out.println("Invalid password. It must contain at least one letter, one digit, and one special character.");
            }
        }


        ArrayList<Customer> customerList = loadCustomersFromFile(CUSTOMERS_FILE);
        for (Customer customer : customerList) {
            if (customer.getName().equalsIgnoreCase(name) && customer.getPassword().equalsIgnoreCase(password)) {
                System.out.println("Login successful. Welcome, " + name + "!");
                return true;
            }
        }
        System.out.println("Invalid Name or Password.");
        return false;
    }

    private static ArrayList<Customer> loadCustomersFromFile(String fileName) {
        try (ObjectInputStream ois = new ObjectInputStream(new FileInputStream(fileName))) {
            return (ArrayList<Customer>) ois.readObject();
        } catch (IOException | ClassNotFoundException e) {
            System.out.println("Error loading customers: " + e.getMessage());
            return new ArrayList<>();
        }
    }

    private static void signUpCustomer(ArrayList<Customer> customerList) {
        Scanner scanner = new Scanner(System.in);

        System.out.println("\n--- Sign Up ---");
        String name, address, city, phone, password;

        // Name input
        while (true) {
            System.out.print("Enter Name: ");
            name = scanner.nextLine();
            if (isValidName(name)) {
                break;
            } else {
                System.out.println("Invalid name. Name cannot be a number.");
            }
        }

        // Address input
        while (true) {
            System.out.print("Enter Address: ");
            address = scanner.nextLine();
            if (isValidAddressOrCity(address)) {
                break;
            } else {
                System.out.println("Invalid address. It cannot be empty or negative.");
            }
        }

        // City input
        while (true) {
            System.out.print("Enter City: ");
            city = scanner.nextLine();
            if (isValidAddressOrCity(city)) {
                break;
            } else {
                System.out.println("Invalid city. It cannot be empty or negative.");
            }
        }

        // Phone number input
        while (true) {
            System.out.print("Enter Phone Number: ");
            phone = scanner.nextLine();
            if (isValidPhoneNumber(phone)) {
                break;
            } else {
                System.out.println("Invalid phone number. It must be 11 digits.");
            }
        }

        // Password input
        while (true) {
            System.out.print("Enter Password: ");
            password = scanner.nextLine();
            if (isValidPassword(password)) {
                System.out.println("Password is valid.");
                break;
            } else {
                System.out.println("Invalid password. It must be at least 8 characters long, contain at least one letter, one digit, and one special character.");
            }
        }

        try {
            Customer newCustomer = new Customer(name, address, city, phone, password);
            customerList.add(newCustomer);
            saveCustomersToFile(CUSTOMERS_FILE, customerList);
            System.out.println("Sign-up successful! You can now log in.");
        } catch (Exception e) {
            System.out.println("An error occurred while signing up: " + e.getMessage());
        }
    }

    private static <T> void saveToFile(String fileName, ArrayList<T> list) {
        try (ObjectOutputStream oos = new ObjectOutputStream(new FileOutputStream(fileName))) {
            oos.writeObject(list);
        } catch (IOException e) {
            System.out.println("Error saving to file: " + e.getMessage());
        }
    }

    public static boolean isValidPhoneNumber(String phone) {
        // Check if the phone number is exactly 11 digits long and contains only digits
        return phone != null && phone.matches("\\d{11}");
    }

    private static boolean isValidStaffId(String staffId) {
        // Check if staffId contains only alphanumeric characters (letters and digits)
        return staffId != null && staffId.matches("[A-Za-z0-9]+");
    }

    public static boolean isValidName(String name) {
        return name != null
                && !name.matches(".*\\d.*")
                && !name.equals("0")
                && !name.equals("-1");
    }

    private static boolean isValidAddressOrCity(String input) {
        return input != null
                && !input.trim().isEmpty()
                && !input.equals("0")
                && !input.equals("-1");
    }

    public static boolean isValidPassword(String password) {
        if (password == null || password.trim().isEmpty()) {
            return false;
        }
        if (!password.matches(".*[A-Za-z].*")) {
            return false;
        }
        if (!password.matches(".*\\d.*")) {
            return false;
        }
        if (!password.matches(".*[!@#$%^&(),.?\":{}|<>].*")) {
            return false;
        }
        return true;
    }

    private static int getValidIntInput() {
        Scanner scanner = new Scanner(System.in);
        int choice;
        while (true) {
            if (scanner.hasNextInt()) {
                choice = scanner.nextInt();
                break;
            } else {
                System.out.print("Invalid input. Please enter a valid number: ");
                scanner.next();
            }
        }
        return choice;
    }
}
