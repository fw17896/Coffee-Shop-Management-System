import javax.swing.*;
import java.io.*;
import java.util.ArrayList;
import java.util.InputMismatchException;
import java.util.List;
import java.util.Scanner;

class Inventory {
    private List<Product> products;

    public Inventory() {
        products = new ArrayList<>();
        loadInventory();
    }

    public List<Product> getProducts() {
        return products;
    }

    public void addProductFromCart(Product product) {
        Product existingProduct = findProduct(product.getName(), product.getSize());
        if (existingProduct != null) {
            existingProduct.setQuantity(existingProduct.getQuantity() + product.getQuantity());
        } else {
            products.add(product);
        }
        saveInventory();
    }

    public void addProduct() {
        Scanner scanner = new Scanner(System.in);
        String name = null;
        String size = null;
        int quantity = 0;
        double price = 0.0;

        while (true) {
            try {
                System.out.print("Enter product name: ");
                name = scanner.nextLine().trim();
                if (name.isEmpty() || name.matches(".*\\d.*")) {
                    throw new IllegalArgumentException("Product name cannot be empty or contain numbers.");
                }
                break;
            } catch (IllegalArgumentException e) {
                System.out.println(e.getMessage());
            }
        }

        while (true) {
            try {
                System.out.print("Enter product size (S, M, L, XL): ");
                size = scanner.nextLine().toUpperCase().trim();
                if (!isValidSize(size)) {
                    throw new IllegalArgumentException("Invalid size! Size must be S, M, L, or XL.");
                }
                break;
            } catch (IllegalArgumentException e) {
                System.out.println(e.getMessage());
            }
        }

        for (Product product : products) {
            if (product.getName().equalsIgnoreCase(name) && product.getSize().equalsIgnoreCase(size)) {
                System.out.println("Product with the same name and size already exists in the inventory.");
                return;
            }
        }

        while (true) {
            try {
                System.out.print("Enter product quantity: ");
                quantity = scanner.nextInt();
                if (quantity <= 0) {
                    throw new IllegalArgumentException("Quantity must be greater than zero.");
                }
                break;
            } catch (InputMismatchException e) {
                System.out.println("Invalid input! Please enter a valid integer for quantity.");
                scanner.nextLine(); // Clear invalid input
            } catch (IllegalArgumentException e) {
                System.out.println(e.getMessage());
            }
        }

        while (true) {
            try {
                System.out.print("Enter product price: ");
                price = scanner.nextDouble();
                if (price <= 0) {
                    throw new IllegalArgumentException("Price must be greater than zero.");
                }
                break;
            } catch (InputMismatchException e) {
                System.out.println("Invalid input! Please enter a valid number for price.");
                scanner.nextLine(); // Clear invalid input
            } catch (IllegalArgumentException e) {
                System.out.println(e.getMessage());
            }
        }

        Product newProduct = new Product(name, size, quantity, price);
        products.add(newProduct);
        saveInventory();
        System.out.println("Product added to inventory!");
    }


    public void checkInventory() {
        loadInventory();
        System.out.println("\n--- Inventory ---");
        for (Product product : products) {
            System.out.println(product);
        }
    }

    public void modifyInventory() {
        Scanner scanner = new Scanner(System.in);

        String name = null;
        while (true) {
            try {
                System.out.print("Enter product name to modify: ");
                name = scanner.nextLine().trim();
                if (name.isEmpty() || name.equals("0") || name.equals("-1")) {
                    throw new IllegalArgumentException("Product name cannot be empty, '0', or '-1'.");
                }
                break;
            } catch (IllegalArgumentException e) {
                System.out.println(e.getMessage());
            }
        }

        String size = null;
        while (true) {
            try {
                System.out.print("Enter product size to modify (S, M, L, XL): ");
                size = scanner.nextLine().trim().toUpperCase();
                if (size.isEmpty() || !isValidSize(size)) {
                    throw new IllegalArgumentException("Invalid size! Size must be S, M, L, or XL.");
                }
                break;
            } catch (IllegalArgumentException e) {
                System.out.println(e.getMessage());
            }
        }

        Product product = findProduct(name, size);
        if (product != null) {
            int quantity = 0;
            while (true) {
                try {
                    System.out.print("Enter new quantity: ");
                    quantity = scanner.nextInt();
                    if (quantity <= 0) {
                        throw new IllegalArgumentException("Quantity must be greater than zero & should not be negative.");
                    }
                    break;
                } catch (InputMismatchException e) {
                    System.out.println("Invalid input! Please enter a valid integer for quantity.");
                    scanner.nextLine(); // Clear invalid input
                } catch (IllegalArgumentException e) {
                    System.out.println(e.getMessage());
                }
            }

            product.setQuantity(quantity);
            saveInventory();
            System.out.println("Product inventory updated!");
        } else {
            System.out.println("Product not found.");
        }
    }

    public Product findProduct(String name, String size) {
        for (Product product : products) {
            if (product.getName().equalsIgnoreCase(name) && product.getSize().equalsIgnoreCase(size)) {
                return product;
            }
        }
        return null;
    }

    public void saveInventory() {
        try (ObjectOutputStream oos = new ObjectOutputStream(new FileOutputStream(CoffeeShop.INVENTORY_FILE))) {
            oos.writeObject(products);
        } catch (IOException e) {
            System.out.println("Error saving inventory: " + e.getMessage());
        }
    }

    public void loadInventory() {
        try (ObjectInputStream ois = new ObjectInputStream(new FileInputStream(CoffeeShop.INVENTORY_FILE))) {
            products = (List<Product>) ois.readObject();
            System.out.println("Inventory loaded from file.");
        } catch (IOException | ClassNotFoundException e) {
            products = new ArrayList<>();
            System.out.println("Error loading inventory: " + e.getMessage());
        }
    }

    public boolean isValidSize(String size) {
        return size.equals("S") || size.equals("M") || size.equals("L") || size.equals("XL");
    }

    public void checkInventoryGUI(JFrame parentFrame) {
        StringBuilder inventoryDetails = new StringBuilder();
        for (Product product : products) {
            inventoryDetails.append(product.toString()).append("\n");
        }
        JOptionPane.showMessageDialog(parentFrame, inventoryDetails.toString(), "Inventory", JOptionPane.INFORMATION_MESSAGE);
    }
}